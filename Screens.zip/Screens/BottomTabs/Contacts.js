import React, { Component } from 'react';
import { TextInput, StyleSheet,TouchableOpacity, View, Text, } from 'react-native'
// import Colors from '../../Constants/Colors'

export default (props) => {
    return( 
        <View>
            <Text style={styles.text}>
                Contacts
            </Text>
        </View>
)}

const styles = StyleSheet.create({ 
})